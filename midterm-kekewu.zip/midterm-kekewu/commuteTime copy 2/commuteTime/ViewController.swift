//
//  ViewController.swift
//  commuteTime
//
//  Created by Keke Wu on 10/19/17.
//  Copyright © 2017 Keke Wu. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var commuteMiles: UITextField!
    @IBOutlet weak var commuteTime: UILabel!
    @IBOutlet weak var gasPurchase: UILabel!
    @IBOutlet weak var imageShow: UIImageView!
    @IBOutlet weak var gasAmountLabel: UILabel!
    @IBOutlet weak var gasAmount: UISlider!
    @IBAction func commuteButton(_ sender: UIButton) {
        if sender.tag == 1{
            commuteTime.text = "60 min"
            gasPurchase.text = "40 gallons"
        }
    }
    @IBAction func gasControl(_ sender: UISlider) {
        let gasValue = sender.value
        gasAmountLabel.text = String(format:"%.0f", gasValue)
    }
    
    @IBOutlet weak var chooseTransportation: UISegmentedControl!
    @IBAction func chooseHow(_ sender: UISegmentedControl) {
        if chooseTransportation.selectedSegmentIndex == 0 {
            imageShow.image = UIImage(named:"car")
        } else if chooseTransportation.selectedSegmentIndex == 1{
                    imageShow.image = UIImage(named:"bus")
        }else if  chooseTransportation.selectedSegmentIndex == 2{
            imageShow.image = UIImage(named:"bike")
        }
    }

    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
            return true
    }
    
    func totalCommuteTime(){
        var roundMiles : Float
        if commuteMiles.text!.isEmpty{
            roundMiles = 0.0
        }else{
            roundMiles = Float(commuteMiles.text!)!
        }
        let totalCommuteTime = roundMiles / 20
        let gasToPruchase = roundMiles / 24
        if roundMiles < 50{
        commuteTime.text = String(totalCommuteTime) + "min"
        gasPurchase.text = String(gasToPruchase) + "gallons"
        }else{
            let alert  = UIAlertController(title:"Warning", message:"You miles are over 50 miles", preferredStyle:UIAlertControllerStyle.alert)
            let cancelAction = UIAlertAction(title:"Cancel", style:UIAlertActionStyle.cancel,handler:nil)
            alert.addAction(cancelAction)
            let okAction = UIAlertAction(title:"OK", style:UIAlertActionStyle.default, handler:{action in
                self.commuteMiles.text = "49"
                self.totalCommuteTime()
                )}
            alert.addAction(okAction)
                present(alert, animated: true, completion:nil)
        }
    }
    
    override func viewDidLoad() {
        commuteMiles.delegate = self
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
          totalCommuteTime()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

